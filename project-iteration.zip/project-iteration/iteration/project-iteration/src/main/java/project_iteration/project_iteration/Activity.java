package project_iteration.project_iteration;

import java.util.List;

public class Activity {
	String Activity_name;//Enter activity title from your story
	String status; // Select the following remarks "TO Do", "In progress", "Done" the status of your activity. 
	String reason; //Enter the reason of your activity from the status: Ex:To Do,reason: New Task
	Integer work_estimated_hours; //You have to enter your estimated hours of work to do the activity 
	List<Capacity> capacity_list;//Show the total days and total hours estimation.

	

}
